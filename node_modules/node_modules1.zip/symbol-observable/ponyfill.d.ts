declare const makeObservableSymbol : (root : object) => symbol;
export default makeObservableSymbol;
