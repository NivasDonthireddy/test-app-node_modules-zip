module.exports = require('./lib/ponyfill');
